package dolphinarium.entities.foods;

public class Herring extends BaseFood {
    private static final int CALORIES = 200 ;

    public Herring() {
        super(CALORIES);
    }
}
