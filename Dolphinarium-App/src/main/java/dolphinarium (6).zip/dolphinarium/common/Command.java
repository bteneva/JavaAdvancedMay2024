package dolphinarium.common;
public enum Command {
    AddPool,
    BuyFood,
    AddFoodToPool,
    AddDolphin,
    FeedDolphins,
    PlayWithDolphins,
    GetStatistics,
    Exit
}

